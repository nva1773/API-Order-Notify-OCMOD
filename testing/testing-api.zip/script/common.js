$(document).ready(function() {
	$('#get_api_token').on('click', function() {
		getApiToken();
	});
	
	$('#test_api_token').on('click', function() {
		testApiToken();
	});
	
	$('#get_orders').on('click', function() {
		getOrders();
	});

	$('#clear_log').on('click', function() {
		$("#log").val('');
	});
});

$(document).on('click','#button_order_info',function(){
    var id = $(this).data('id');
	getOrderInfo(id);
});

function getApiToken() {
	let site_url = $("#site_url").val();
	let user_name = $("#user_name").val();
	let api_key = $("#api_key").val().split('\n').join('');
	let url = "";
	if(site_url.length < 15) {
		log("error site url");
		return;
	} else {
		url = site_url;
	}
	if(user_name.length != 0) {
		if (user_name.length >= 3 && user_name.length <= 26) {
			url += "index.php?route=api/login&api_username=" + user_name + "&api_key=";
		} else {
			log("error user name");
			return;
		}
	} else {
		url += "index.php?route=api/login&api_key=";
	}
	if(api_key.length >= 64 && api_key.length <= 256) {
		url += api_key;
	} else {
		log("error api key");
		return;
	}
	
	log("request:\n" + url);
	
	$.ajax({
		url: url,
		type: "GET",
		dataType: 'json',
		success: function (json) {
			if(json['success'] == "true") {
				$("#api_token").val(json['api_token']);
				log("response:\n" + JSON.stringify(json) + "\n");
				$('#test_api_token').prop('disabled', false);
				$('#get_orders').prop('disabled', false);
			} else {
				$("#api_token").val("");
				log("error:\n" + json['error']);
			}
		},
		error: function(xhr, ajaxOptions, thrownError) {
			log("error:\n" + "No 'Access-Control-Allow-Origin' header is present on the requested resource.");
		}
	});
}

function testApiToken() {
	let site_url = $("#site_url").val();
	let api_token = $("#api_token").val();
	let url = "";
	if(site_url.length < 15) {
		log("error site url");
		return;
	} else {
		url = site_url;
	}
	if (api_token.length == 26) {
		url += "index.php?route=api/sale&api_token=" + api_token;
	} else {
		log("error api token");
		return;
	}
	
	log("request:\n" + url);
	
	$.ajax({
		url: url,
		type: "GET",
		dataType: 'json',
		success: function (json) {
			if(json['success'] == "true") {
				log("response:\n" + JSON.stringify(json) + "\n");
			} else {
				$("#api_token").val("");
				log("error:\n" + json['error']);
			}
		},
		error: function(xhr, ajaxOptions, thrownError) {
			log("error:\n" + "No 'Access-Control-Allow-Origin' header is present on the requested resource.");
		}
	});
}

function getOrders() {
	let site_url = $("#site_url").val();
	let api_token = $("#api_token").val();
	let url = "";
	if(site_url.length < 15) {
		log("error site url");
		return;
	} else {
		url = site_url;
	}
	if (api_token.length == 26) {
		url += "index.php?route=api/sale/orders&api_token=" + api_token;
	} else {
		log("error api token");
		return;
	}
	
	log("request:\n" + url);
	
	$('#new_orders').remove();
	
	$.ajax({
		url: url,
		type: "GET",
		dataType: 'json',
		success: function (json) {
			if(json['success'] == "true") {
				let orders_total = json['orders_total'];
				let sale_total = json['sale_total'];
				$("#orders").val(orders_total);
				$("#total").val(sale_total);
				if (orders_total > 0) {
					let orders = json['orders'];
					if (orders.length > 0) {
						html = '<div class="panel-body" id="new_orders">';
						for(i = 0; i < orders.length; i++) {
							let order_id = orders[i]['order_id'];
							let customer = orders[i]['customer'];
							let date_added = orders[i]['date_added'];
							let total = orders[i]['total'];
							
							html += '<div role="button" class="btn-info" id="button_order_info" data-id="' + order_id + '">';
							html += '  <div><u>OrderId&nbsp;' + order_id + '</u></div>';
							html += '  <p>Customer:&nbsp;' + customer + '</p>';
							html += '  <p>Total:&nbsp;' + total + '</p>';
							html += '  <span>' + date_added + '</span>';
							html += '</div>';
						}
						html += '</div>';
						$(html).insertAfter($("#orders_total"));
					}
				} else {
						$('#order_info').html("");
				}
				log("response:\n" + JSON.stringify(json) + "\n");
			} else {
				log("error:\n" + json['error']);
			}
		},
		error: function(xhr, ajaxOptions, thrownError) {
			log("error:\n" + "No 'Access-Control-Allow-Origin' header is present on the requested resource.");
		}
	});
}

function getOrderInfo(id) {
	let site_url = $("#site_url").val();
	let api_token = $("#api_token").val();
	let order_id = id;
	let url = "";
	if(site_url.length < 15) {
		log("error site url");
		return;
	} else {
		url = site_url;
	}
	if (api_token.length == 26 && order_id > 0) {
		url += "index.php?route=api/sale/order&api_token=" + api_token + "&order_id=" + order_id;
	} else {
		log("error api token or order id");
		return;
	}
	
	log("request:\n" + url);
	
	$.ajax({
		url: url,
		type: "GET",
		dataType: 'json',
		success: function (json) {
			if(json['success'] == "true") {
				log("response:\n" + JSON.stringify(json) + "\n");
				let info = json['order_info'].split(';-\n').join(';- - - - - - - - - - - - - - - - - -\n');
				$('#order_info').html(info);
				$('#tab_2').trigger('click');
			} else {
				log("error:\n" + json['error']);
			}
		},
		error: function(xhr, ajaxOptions, thrownError) {
			log("error:\n" + "No 'Access-Control-Allow-Origin' header is present on the requested resource.");
		}
	});
}

function log(data) {
	let str_log = $("#log").val() + data + "\n";
	$("#log").val(str_log);		
	let scroll = $("#log");
	scroll.scrollTop(scroll.prop('scrollHeight') - scroll.height());
}
