<?php
class ControllerApiSale extends Controller {
    // test api_token
	// https://site.url/index.php?route=api/sale&api_token=api_token
	public function index() {
		$json = array();
		
		$this->load->model('account/api');
		
		$json['success'] = "false";
		$json['error'] = "";
		
		if (isset($this->request->get['api_token'])) {
			$results = $this->model_account_api->getApiSession($this->request->get['api_token']);
			if ($results) {
				$json['success'] = "true";
			} else {
				$json['error'] = "Incorrect API Token!";
			}
		} else {
			$json['error'] = "API Token is empty!";
		}			
				
		$this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
    }
	
	// get the last seven unprocessed orders: status == 1 (Pending) or == 2 (Processing)
	// https://site.url/index.php?route=api/sale/orders&api_token=api_token
	public function orders() {
		$json = array();
		
		$json['success'] = "false";
		$json['orders'] = array();
		$json['orders_total'] = 0;
		$json['sale_total'] = 0;
		$json['error'] = "";
		
		$this->load->model('account/api');
		
		if (isset($this->request->get['api_token'])) {
			$results = $this->model_account_api->getApiSession($this->request->get['api_token']);
			if ($results) {
				$json['success'] = "true";

				$this->load->model('checkout/api');
				
				$filter_data = array(
					'sort'  => 'o.date_added',
					'order' => 'DESC',
					'filter_order_status' => '1,2',
					'start' => 0,
					'limit' => 7
				);
				
				$orders = $this->model_checkout_api->getOrders($filter_data);
								
				foreach ($orders as $order) {
					$json['orders'][] = array(
						'order_id'   => $order['order_id'],
						'customer'   => $order['customer'],
						'date_added' => date($this->language->get('datetime_format'), strtotime($order['date_added'])),
						'total'      => $this->currency->format($order['total'], $order['currency_code'], $order['currency_value'])
					);
					$json['orders_total'] += 1;
					$json['sale_total'] += $order['total']/$order['currency_value'];
				}
			} else {
				$json['error'] = "Incorrect API Token!";	
			}
		} else {
			$json['error'] = "API Token is empty!";
		}

		$this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
	}
	
	// get order info
	// https://site.url/index.php?route=api/sale/order&api_token=api_token&order_id=order_id
	public function order() {
		$json = array();
		
		$json['success'] = "false";
		$json['order_info'] = "";
		$json['error'] = "";
		
		$this->load->model('account/api');
		
		if (isset($this->request->get['api_token'])) {
			$results = $this->model_account_api->getApiSession($this->request->get['api_token']);
			if ($results) {
				if (isset($this->request->get['order_id'])) {
					$order_id = $this->request->get['order_id'];
					
					$this->load->model('checkout/order');

					$order_info = $this->model_checkout_order->getOrder($order_id);
					
					if ($order_info) {
						$json['success'] = "true";
						
						$this->load->language('mail/order_alert');
						
						// data added
						$date_added = date($this->language->get('datetime_format'), strtotime($order_info['date_added']));
						
						// payment and shipping
						$payment_method = $order_info['payment_method'];
						$shipping_method = $order_info['shipping_method'];
						
						$find = array(
							'{country}',
							'{zone}',
							'{city}',
							'{address_1}',
							'{postcode}'
						);

						$replace = array(
							'country'   => $order_info['shipping_country'],
							'zone'      => $order_info['shipping_zone'],
							'city'      => $order_info['shipping_city'],
							'address_1' => $order_info['shipping_address_1'],
							'postcode'  => $order_info['shipping_postcode']
						);
						
						$format = '{country}' . "\n" . '{zone}' . "\n" . '{city}' . "\n" . '{address_1}' . "\n" . '{postcode}';

						$shipping_address = str_replace(array("\r\n", "\r", "\n"), '<br />', preg_replace(array("/\s\s+/", "/\r\r+/", "/\n\n+/"), '<br />', trim(str_replace($find, $replace, $format))));

						// products
						$this->load->model('tool/upload');
						
						$order_products = $this->model_checkout_order->getOrderProducts($order_id);
						$products = "";

						foreach ($order_products as $order_product) {
							$products .= $order_product['name'] . "\n";
							$products .= $this->language->get('text_model') . ": " . $order_product['model'] . "       ";
							$products .= $this->language->get('text_quantity') . ": " . $order_product['quantity'] . "\n\n";
						}
						
						// total
						$total['totals'] = array();
						
						$order_totals = $this->model_checkout_order->getOrderTotals($order_id);

						foreach ($order_totals as $order_total) {
							$total['totals'][] = array(
								'text'  => $this->currency->format($order_total['value'], $order_info['currency_code'], $order_info['currency_value'])
							);
						}

						// client name
						$client_name = $this->language->get('text_one_click');
						if( $order_info['shipping_firstname'] or $order_info['shipping_lastname']){
							$client_name = $order_info['shipping_firstname'] . " " . $order_info['shipping_lastname'];
						}
						
						// customer group
						$this->load->model('account/customer');
						$customer = $this->model_account_customer->getCustomer($order_info['customer_id']);
						if ($customer and isset($customer['customer_group_id'])) {
							$this->load->model('account/customer_group');
							$customer_group_info = $this->model_account_customer_group->getCustomerGroup($customer['customer_group_id']);
							if ($customer_group_info) {
								$customer_group = $customer_group_info['description'];
							} else {
								$customer_group = '';
							}
						} else {
							$customer_group = '';
						}
						
						$json['order_info'] = ";-\n";
						$json['order_info'] .= $this->language->get('text_order_id') . " " . $order_id . "\n";
						$json['order_info'] .= $this->language->get('text_date_added') . " " . $date_added . "\n";
						if ($customer_group) $json['order_info'] .= $this->language->get('text_group') . ": " . $customer_group . "\n";
						$json['order_info'] .= $this->language->get('text_name') . ": " . $client_name . "\n";
						$json['order_info'] .= $this->language->get('text_telephone') . " " . $order_info['telephone'] . "\n";
						$json['order_info'] .= ";-\n";
						$json['order_info'] .= $products;
						$json['order_info'] .= $this->language->get('text_total') . ": " . str_replace("&nbsp;"," ", $total['totals'][0]['text']) . "\n";
						$json['order_info'] .= ";-\n";
						if ($payment_method) $json['order_info'] .= $payment_method . "\n\n";
						if ($shipping_method) $json['order_info'] .= $shipping_method . "\n\n";
						if ($shipping_address) $json['order_info'] .= str_replace("<br />","\n", $shipping_address) . "\n";
						if ($payment_method or $shipping_method or $shipping_address)
							$json['order_info'] .= ";-\n";
						
					} else {
						$json['error'] = "Incorrect Order ID!";
					}
				} else {
					$json['error'] = "Order ID is empty!";
				}
			} else {
				$json['error'] = "Incorrect API Token!";	
			}
		} else {
			$json['error'] = "API Token is empty!";
		}

		$this->response->addHeader('Content-Type: application/json');
        $this->response->setOutput(json_encode($json));
	}
}